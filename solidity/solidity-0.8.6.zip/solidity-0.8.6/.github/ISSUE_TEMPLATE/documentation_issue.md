---
name: Documentation Issue
about: Solidity documentation.
---

## Page

<!--
Please link directly to the page which you think has a problem
-->

## Abstract

<!--
Please describe in detail what is wrong.
-->

## Pull request

<!--
Please link to your pull request which resolves this issue
-->
